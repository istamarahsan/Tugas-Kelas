import java.util.Arrays;

public class ExampleSatu {
    public static void main(String[] args) {
        int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        System.out.println("Print Even Numbers");
        Arrays.stream(numbers)
                .filter(i -> isEven(i))
                .forEach(System.out::println);

        System.out.println("Print Odd Numbers");
        Arrays.stream(numbers)
                .filter(i -> !isEven(i)) //odd
                .forEach(System.out::println);

        System.out.println("Print Numbers multiplied by 2");
        Arrays.stream(numbers)
                .map(i -> i * 2)
                .forEach(System.out::println);

       System.out.println("Print Numbers divided by 2");
        Arrays.stream(numbers)
                .mapToDouble(i -> (double)i)
                .map(i -> i / 2.0)
                .forEach(System.out::println);
    }

    private static boolean isEven(int i) {
        return i % 2 == 0;
    }
}
